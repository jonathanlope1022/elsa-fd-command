ELSA FD INCIDENT COMMAND PWA

This app must be hosted on an HTTPS website for full PWA installation and offline support.

Easy hosting options:
1. GitHub Pages
2. Netlify Drop
3. Cloudflare Pages
4. Your city/department web server

After hosting:
- Open the HTTPS link in Safari on the iPad.
- Tap Share.
- Tap Add to Home Screen.
- Open the Elsa FD IC icon.
- Open it once while online so the offline cache installs.

The app stores incident data locally in Safari on that device.
Use Print / Save PDF for a permanent incident record.
